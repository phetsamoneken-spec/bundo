import { CartItem, Order, StoreProfile } from '../types/pos';

export function formatKip(num: number): string {
  return new Intl.NumberFormat('lo-LA').format(Math.max(0, Math.round(num)));
}

export function formatDateTimeLao(isoDateString: string): string {
  try {
    const d = new Date(isoDateString);
    return d.toLocaleString('lo-LA', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    });
  } catch {
    return isoDateString;
  }
}

export function vibrateSoft(duration = 25): void {
  if (typeof window !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(duration);
    } catch {
      // Ignore vibration errors if blocked by browser policy
    }
  }
}

export function compressImage(file: File, maxWidth = 640, quality = 0.7): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = reject;
      img.src = e.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function buildWhatsAppSlip(
  cartItems: CartItem[],
  subtotal: number,
  discount: number,
  total: number,
  notes: string,
  profile: StoreProfile,
  orderId?: string
): string {
  const currentId = orderId || `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
  const dateStr = formatDateTimeLao(new Date().toISOString());

  const lines = [
    `🧾 *ໃບບິນສະຫຼຸບອໍເດີ້ / ORDER SUMMARY*`,
    `🏪 *ຊື່ຮ້ານ:* ${profile.name}`,
    `👤 *ເຈົ້າຂອງຮ້ານ / ຜູ້ຕິດຕໍ່:* ${profile.ownerName || profile.cashierName || 'ເຈົ້າຂອງຮ້ານ'}`,
    `📞 *ເບີໂທຕິດຕໍ່:* ${profile.phone || '-'}`,
    `🔖 *ເລກທີອໍເດີ້:* ${currentId}`,
    `📅 *ວັນທີ-ເວລາ:* ${dateStr}`,
  ];

  if (profile.lat && profile.lng) {
    lines.push(`📍 *Location (ພິກັດຮ້ານ):* https://www.google.com/maps?q=${profile.lat.toFixed(5)},${profile.lng.toFixed(5)}`);
  }

  lines.push(`📸 *ຮູບໜ້າຮ້ານ:* ${profile.photoUrl ? 'ແນບຮູບໜ້າຮ້ານແລ້ວ ✅' : 'ຍັງບໍ່ໄດ້ແນບຮູບ'}`);

  lines.push('');
  lines.push('📋 *ລາຍການສິນຄ້າທີ່ສັ່ງ:*');

  cartItems.forEach((item, index) => {
    const itemTotal = item.quantity * item.product.price;
    lines.push(
      `${index + 1}. ${item.product.name} x${item.quantity} = ${formatKip(itemTotal)} ກີບ`
    );
  });

  lines.push('------------------------------');
  lines.push(`💵 *ຍອດລວມ:* ${formatKip(subtotal)} ກີບ`);
  if (discount > 0) {
    lines.push(`🏷️ *ສ່ວນຫຼຸດ:* -${formatKip(discount)} ກີບ`);
  }
  lines.push(`💰 *ຍອດຊຳລະສຸດທິ:* *${formatKip(total)} ກີບ*`);
  lines.push('------------------------------');

  if (notes.trim()) {
    lines.push(`📝 *ໝາຍເຫດ:* ${notes.trim()}`);
  }

  lines.push('');
  lines.push('🙏 *ຂອບໃຈຫຼາຍໆ ທີ່ມາອຸດໜູນຮ້ານເຮົາ!*');

  return lines.join('\n');
}

export function exportOrdersToCSV(orders: Order[]): void {
  if (orders.length === 0) return;

  const headers = [
    'Order ID',
    'Date Time',
    'Store Name',
    'Cashier',
    'Items Summary',
    'Subtotal (LAK)',
    'Discount (LAK)',
    'Total Net (LAK)',
    'Notes',
    'Map Lat',
    'Map Lng',
    'Dispatch Mode',
  ];

  const rows = orders.map((order) => {
    const itemsSummary = order.items
      .map((it) => `${it.productName} x${it.quantity}`)
      .join(' | ');

    return [
      `"${order.id}"`,
      `"${formatDateTimeLao(order.createdAt)}"`,
      `"${order.storeName}"`,
      `"${order.cashierName || ''}"`,
      `"${itemsSummary.replace(/"/g, '""')}"`,
      order.subtotal,
      order.discount,
      order.total,
      `"${(order.notes || '').replace(/"/g, '""')}"`,
      order.location?.lat || '',
      order.location?.lng || '',
      `"${order.dispatchMode}"`,
    ].join(',');
  });

  const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `lao-pos-orders-${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
