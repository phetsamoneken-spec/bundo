import React from 'react';
import { ActiveTab } from '../types/pos';

interface HeaderProps {
  activeTab: ActiveTab;
  onOpenGpsModal: () => void;
  onQuickSync: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenGpsModal,
  onQuickSync,
}) => {
  const getTabSubtitle = () => {
    switch (activeTab) {
      case 'pos-menu':
        return 'Pos Menu';
      case 'cart-and-whatsapp':
        return 'Cart & WhatsApp';
      case 'sales-dashboard':
        return 'Sales Dashboard';
      case 'order-history':
        return 'Order History';
      case 'catalog-settings':
        return 'Catalog Settings';
    }
  };

  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-[#faf8ff]/85 backdrop-blur-xl shadow-[0_1px_12px_rgba(0,108,73,0.06)] border-b border-emerald-900/5">
      <div className="h-16 max-w-lg mx-auto px-4 flex items-center justify-between gap-2">
        {/* Left Branding & GPS status */}
        <div className="flex items-center gap-2.5 min-w-0 flex-1">
          {/* Green POS Logo Icon Box */}
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#006c49] to-[#10b981] flex items-center justify-center text-white shrink-0 shadow-sm shadow-emerald-900/20">
            <span className="material-symbols-outlined text-[24px]">point_of_sale</span>
          </div>

          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-1">
              <span className="font-display font-bold text-[17px] text-[#006c49] truncate leading-tight tracking-tight">
                ຮ້ານ ກາເຟ &amp; ອາຫານ ລາວ POS
              </span>
            </div>
            <button
              onClick={onOpenGpsModal}
              className="flex items-center gap-1 mt-0.5 text-left group transition-opacity active:opacity-75"
              title="ກົດເພື່ອຕັ້ງຄ່າ GPS"
            >
              <span className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse shrink-0"></span>
              <span className="text-[12px] text-[#3c4a42] flex items-center gap-0.5 truncate font-medium">
                <span className="material-symbols-outlined text-[13px] text-[#006c49]">location_on</span>
                GPS ເປີດໃຊ້ງານ • <span className="text-[#006c49] font-bold group-hover:underline">{getTabSubtitle()}</span>
              </span>
            </button>
          </div>
        </div>

        {/* Right Action Icons */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={onQuickSync}
            className="w-10 h-10 rounded-full flex items-center justify-center text-[#3c4a42] hover:text-[#006c49] hover:bg-[#ecfdf5] transition-colors active:scale-95"
            aria-label="Cloud sync"
            title="ຊິງຄ໌ຂໍ້ມູນອອບໄລນ໌"
          >
            <span className="material-symbols-outlined text-[22px]">wifi_tethering</span>
          </button>
          <div
            className="w-8 h-8 rounded-full bg-[#006c49] flex items-center justify-center shrink-0 shadow-sm cursor-pointer hover:bg-[#005236] transition-colors active:scale-95"
            title="ຜູ້ໃຊ້ງານ: Cashier POS"
          >
            <span className="material-symbols-outlined text-white text-[18px]">person</span>
          </div>
        </div>
      </div>
    </header>
  );
};
