import React from 'react';

export interface ToastMessage {
  id: string;
  type: 'success' | 'info' | 'warning' | 'error';
  message: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const Toast: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-18 inset-x-0 z-50 flex flex-col items-center gap-2 pointer-events-none px-4">
      {toasts.map((toast) => {
        const bgColors = {
          success: 'bg-[#006c49] text-white',
          info: 'bg-[#1e293b] text-white',
          warning: 'bg-[#f59e0b] text-[#131b2e]',
          error: 'bg-[#ba1a1a] text-white',
        };

        const icons = {
          success: 'check_circle',
          info: 'info',
          warning: 'warning',
          error: 'error',
        };

        return (
          <div
            key={toast.id}
            onClick={() => onDismiss(toast.id)}
            className={`pointer-events-auto flex items-center gap-2 px-4 py-2.5 rounded-2xl shadow-xl backdrop-blur-md text-sm font-medium transition-all duration-300 transform translate-y-0 active:scale-95 cursor-pointer max-w-sm w-full ${bgColors[toast.type]}`}
          >
            <span className="material-symbols-outlined text-[20px] shrink-0">
              {icons[toast.type]}
            </span>
            <span className="flex-1 leading-snug">{toast.message}</span>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDismiss(toast.id);
              }}
              className="opacity-70 hover:opacity-100 transition-opacity p-0.5"
            >
              <span className="material-symbols-outlined text-[16px]">close</span>
            </button>
          </div>
        );
      })}
    </div>
  );
};
