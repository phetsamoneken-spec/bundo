import React, { useState, useMemo } from 'react';
import { Product, ProductCategory, CartItem } from '../../types/pos';
import { formatKip, vibrateSoft } from '../../utils/formatters';

interface MenuTabProps {
  products: Product[];
  cart: Record<string, number>;
  onUpdateQty: (productId: string, delta: number) => void;
  onSetQty: (productId: string, quantity: number) => void;
  onGoToCart: () => void;
}

export const MenuTab: React.FC<MenuTabProps> = ({
  products,
  cart,
  onUpdateQty,
  onSetQty,
  onGoToCart,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | ProductCategory>('all');
  const [searchKeyword, setSearchKeyword] = useState('');

  // Calculate cart totals
  const { cartTotalCount, cartTotalKip } = useMemo(() => {
    let count = 0;
    let kip = 0;
    for (const [productId, qty] of Object.entries(cart)) {
      if (qty > 0) {
        count += qty;
        const prod = products.find((p) => p.id === productId);
        if (prod) {
          kip += prod.price * qty;
        }
      }
    }
    return { cartTotalCount: count, cartTotalKip: kip };
  }, [cart, products]);

  // Filter products by category and search term
  const filteredProducts = useMemo(() => {
    return products.filter((prod) => {
      const matchCat = selectedCategory === 'all' || prod.category === selectedCategory;
      const term = searchKeyword.trim().toLowerCase();
      const matchSearch =
        !term ||
        prod.name.toLowerCase().includes(term) ||
        prod.nameEn.toLowerCase().includes(term) ||
        prod.sub.toLowerCase().includes(term);
      return matchCat && matchSearch;
    });
  }, [products, selectedCategory, searchKeyword]);

  const categories = [
    { id: 'all', label: 'ທັງໝົດ', icon: 'apps', count: products.length },
    { id: 'drinks', label: 'ເຄື່ອງດື່ມ', icon: 'local_cafe' },
    { id: 'food', label: 'ອາຫານ', icon: 'restaurant' },
    { id: 'desserts', label: 'ຂອງຫວານ', icon: 'bakery_dining' },
  ];

  const renderBadge = (product: Product) => {
    if (!product.badgeText) return null;

    if (product.badgeType === 'bestseller') {
      return (
        <span className="absolute top-2 right-2 bg-white/95 backdrop-blur-md text-[#006c49] font-bold text-[12px] px-2 py-0.5 rounded-full shadow-sm flex items-center gap-0.5">
          <span className="material-symbols-outlined text-[13px] text-[#f59e0b] fill-current">star</span>
          <span>{product.badgeText}</span>
        </span>
      );
    }

    if (product.badgeType === 'sweet') {
      return (
        <span className="absolute top-2 left-2 bg-white/95 backdrop-blur-md text-[#3c4a42] font-semibold text-[12px] px-2 py-0.5 rounded-full shadow-sm">
          {product.badgeText}
        </span>
      );
    }

    if (product.badgeType === 'recommended') {
      return (
        <span className="absolute top-2 right-2 bg-[#006c4e] text-white font-bold text-[12px] px-2.5 py-0.5 rounded-full shadow-sm">
          {product.badgeText}
        </span>
      );
    }

    if (product.badgeType === 'spicy') {
      return (
        <span className="absolute top-2 left-2 bg-[#f43f5e] text-white font-bold text-[12px] px-2 py-0.5 rounded-full shadow-sm flex items-center gap-0.5">
          <span className="material-symbols-outlined text-[12px]">local_fire_department</span>
          <span>{product.badgeText}</span>
        </span>
      );
    }

    return (
      <span className="absolute top-2 right-2 bg-[#10b981] text-white font-bold text-[12px] px-2 py-0.5 rounded-full shadow-sm">
        {product.badgeText}
      </span>
    );
  };

  return (
    <div className="flex flex-col w-full pb-36">
      {/* Top Search & Welcoming Tone */}
      <section className="px-4 pt-2 pb-2 max-w-lg mx-auto w-full">
        <div className="flex items-baseline justify-between mb-2">
          <div>
            <h1 className="font-display font-bold text-[24px] text-[#006c49] tracking-tight leading-tight">
              ເມນູສິນຄ້າ
            </h1>
            <p className="text-[14px] text-[#3c4a42]">ຊອກຫາເມນູ ແລະ ເລືອກລາຍການຂາຍ</p>
          </div>
          <div className="flex items-center gap-1.5 bg-[#ecfdf5] px-3 py-1 rounded-full shadow-xs border border-[#a7f3d0]/60">
            <span className="w-2 h-2 rounded-full bg-[#10b981] animate-pulse"></span>
            <span className="text-[12px] text-[#006c49] font-bold">
              ພ້ອມເສີບ {products.length} ລາຍການ
            </span>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative w-full mt-1">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#006c49]">
            <span className="material-symbols-outlined text-[20px]">search</span>
          </div>
          <input
            type="text"
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            placeholder="ຄົ້ນຫາເມນູສິນຄ້າ..."
            className="w-full h-12 pl-10 pr-10 bg-white text-[#131b2e] text-[14px] rounded-2xl shadow-sm border border-emerald-900/10 focus:outline-none focus:ring-2 focus:ring-[#10b981]/40 transition-all placeholder:text-gray-400"
          />
          {searchKeyword.length > 0 && (
            <button
              type="button"
              onClick={() => {
                vibrateSoft();
                setSearchKeyword('');
              }}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-[#3c4a42] hover:text-[#006c49] active:scale-90 transition-transform"
            >
              <span className="material-symbols-outlined text-[18px]">cancel</span>
            </button>
          )}
        </div>
      </section>

      {/* Category Filter Pills */}
      <section className="w-full overflow-x-auto no-scrollbar py-1 px-4 max-w-lg mx-auto flex gap-2">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => {
                vibrateSoft(15);
                setSelectedCategory(cat.id as any);
              }}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-[14px] font-semibold transition-all duration-200 shadow-xs flex items-center gap-1.5 active:scale-95 ${
                isActive
                  ? 'bg-[#006c49] text-white shadow-md'
                  : 'bg-white text-[#131b2e] hover:text-[#006c49] border border-gray-100'
              }`}
            >
              <span className="material-symbols-outlined text-[16px]">{cat.icon}</span>
              <span>{cat.label}</span>
              {typeof cat.count === 'number' && (
                <span
                  className={`px-1.5 py-0.5 rounded-full text-[11px] font-bold ml-0.5 ${
                    isActive ? 'bg-[#10b981] text-white' : 'bg-gray-100 text-gray-700'
                  }`}
                >
                  {cat.count}
                </span>
              )}
            </button>
          );
        })}
      </section>

      {/* Product Grid */}
      <section className="px-4 pt-2 pb-6 max-w-lg mx-auto w-full">
        {filteredProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center py-12 px-4">
            <div className="w-16 h-16 rounded-full bg-[#ecfdf5] flex items-center justify-center text-[#006c49] mb-3">
              <span className="material-symbols-outlined text-[32px]">manage_search</span>
            </div>
            <h4 className="font-display font-bold text-[18px] text-[#131b2e]">
              ບໍ່ພົບລາຍການທີ່ຄົ້ນຫາ
            </h4>
            <p className="text-[14px] text-[#3c4a42] mt-1 max-w-xs">
              ລອງຄົ້ນຫາດ້ວຍຊື່ເມນູອື່ນ ຫຼື ກົດປຸ່ມເລືອກໝວດໝູ່ດ້ານເທິງ
            </p>
            <button
              onClick={() => {
                vibrateSoft();
                setSearchKeyword('');
                setSelectedCategory('all');
              }}
              className="mt-4 px-4 py-2 bg-[#006c49] text-white rounded-xl text-[14px] font-semibold active:scale-95 transition-transform shadow-sm"
            >
              ເບິ່ງເມນູທັງໝົດ
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filteredProducts.map((product) => {
              const qty = cart[product.id] || 0;

              return (
                <article
                  key={product.id}
                  className="group flex flex-col bg-white rounded-2xl p-2.5 shadow-sm transition-all hover:shadow-md border border-gray-100 relative overflow-hidden"
                >
                  {/* Image container */}
                  <div className="relative w-full aspect-square rounded-xl overflow-hidden bg-[#ecfdf5] mb-2 shadow-inner">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      loading="lazy"
                    />
                    {renderBadge(product)}
                  </div>

                  {/* Title and details */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-display font-bold text-[17px] text-[#131b2e] line-clamp-1 leading-snug">
                        {product.name}
                      </h3>
                      <p className="text-[12px] text-[#3c4a42] truncate mt-0.5">
                        {product.nameEn} • {product.sub}
                      </p>
                    </div>

                    <div className="mt-2.5">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-display font-black text-[20px] text-[#006c49] leading-none">
                          {formatKip(product.price)}
                        </span>
                        <span className="text-[12px] text-[#3c4a42] font-semibold">ກີບ</span>
                      </div>

                      {/* Add Button or Stepper */}
                      {qty === 0 ? (
                        <button
                          type="button"
                          onClick={() => {
                            vibrateSoft(20);
                            onUpdateQty(product.id, 1);
                          }}
                          className="w-full h-10 bg-[#ecfdf5] hover:bg-[#97f5cc] text-[#006c49] font-bold text-[14px] rounded-xl flex items-center justify-center gap-1 active:scale-95 transition-all shadow-xs border border-[#a7f3d0]/50"
                        >
                          <span className="material-symbols-outlined text-[18px]">add</span>
                          <span>ເພີ່ມ</span>
                        </button>
                      ) : (
                        <div className="flex items-center justify-between bg-[#ecfdf5] rounded-xl p-1 shadow-sm border border-[#a7f3d0]/50">
                          <button
                            type="button"
                            onClick={() => {
                              vibrateSoft(20);
                              onUpdateQty(product.id, -1);
                            }}
                            className="w-8 h-8 rounded-lg bg-white text-[#006c49] flex items-center justify-center font-bold shadow-xs active:scale-90 transition-transform"
                            aria-label="Decrease quantity"
                          >
                            <span className="material-symbols-outlined text-[18px]">remove</span>
                          </button>

                          <input
                            type="number"
                            min="0"
                            max="999"
                            value={qty}
                            onChange={(e) => {
                              const val = parseInt(e.target.value, 10);
                              onSetQty(product.id, isNaN(val) ? 0 : val);
                            }}
                            onFocus={(e) => e.target.select()}
                            className="w-10 text-center bg-transparent font-display font-black text-[18px] text-[#006c49] focus:outline-none"
                          />

                          <button
                            type="button"
                            onClick={() => {
                              vibrateSoft(20);
                              onUpdateQty(product.id, 1);
                            }}
                            className="w-8 h-8 rounded-lg bg-[#006c49] text-white flex items-center justify-center font-bold shadow-xs active:scale-90 transition-transform"
                            aria-label="Increase quantity"
                          >
                            <span className="material-symbols-outlined text-[18px]">add</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Floating Quick Cart Drawer Bar */}
      {cartTotalCount > 0 && (
        <aside className="fixed bottom-20 inset-x-0 z-40 px-3 pointer-events-none">
          <div className="pointer-events-auto mx-auto max-w-lg bg-[#1e293b]/95 backdrop-blur-xl text-white rounded-2xl p-3 shadow-[0_16px_36px_-6px_rgba(0,0,0,0.35)] flex items-center justify-between gap-2 border border-white/10 animate-slideUp">
            <div className="flex items-center gap-3 min-w-0">
              <div className="relative w-11 h-11 rounded-xl bg-[#006c49] flex items-center justify-center text-white shrink-0 shadow-sm">
                <span className="material-symbols-outlined text-[24px]">shopping_cart</span>
                <span className="absolute -top-1.5 -right-1.5 bg-[#f43f5e] text-white font-display text-[11px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center shadow-md">
                  {cartTotalCount > 99 ? '99+' : cartTotalCount}
                </span>
              </div>
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[12px] text-white/80">
                    ລວມ <span className="font-bold text-white">{cartTotalCount}</span> ລາຍການ
                  </span>
                  <span className="w-1 h-1 rounded-full bg-[#10b981]"></span>
                  <span className="text-[12px] text-[#4edea3] font-semibold">ພ້ອມສັ່ງ</span>
                </div>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="font-display text-[22px] text-[#4edea3] font-black tracking-tight leading-none">
                    {formatKip(cartTotalKip)}
                  </span>
                  <span className="text-[12px] text-white/75">ກີບ</span>
                </div>
              </div>
            </div>

            {/* Action Button to Cart & WhatsApp */}
            <button
              onClick={() => {
                vibrateSoft();
                onGoToCart();
              }}
              className="h-11 px-4 bg-[#10b981] hover:bg-[#0ea271] text-white font-display font-bold text-[15px] rounded-xl flex items-center gap-1.5 shrink-0 shadow-md active:scale-95 transition-all"
            >
              <span>ໄປທີ່ກະຕ່າສັ່ງຊື້</span>
              <span className="material-symbols-outlined text-[18px]">arrow_forward</span>
            </button>
          </div>
        </aside>
      )}
    </div>
  );
};
