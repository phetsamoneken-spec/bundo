import React, { useState } from 'react';
import { Order, StoreProfile } from '../../types/pos';
import { formatKip, formatDateTimeLao, vibrateSoft, exportOrdersToCSV, buildWhatsAppSlip } from '../../utils/formatters';

interface OrdersTabProps {
  orders: Order[];
  onDeleteOrder: (id: string) => void;
  onClearAllOrders: () => void;
  profile: StoreProfile;
  onShowToast: (msg: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const OrdersTab: React.FC<OrdersTabProps> = ({
  orders,
  onDeleteOrder,
  onClearAllOrders,
  profile,
  onShowToast,
}) => {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Resend to WhatsApp
  const handleResendWhatsApp = (order: Order) => {
    vibrateSoft();
    const cartItems = order.items.map((it) => ({
      product: {
        id: it.productId,
        name: it.productName,
        nameEn: it.productNameEn,
        sub: '',
        category: it.category,
        price: it.unitPrice,
        image: '',
      },
      quantity: it.quantity,
    }));

    const orderProfile: StoreProfile = {
      ...profile,
      name: order.storeName || profile.name,
      ownerName: order.ownerName || profile.ownerName,
      lat: order.location?.lat ?? profile.lat,
      lng: order.location?.lng ?? profile.lng,
      photoUrl: order.storePhoto ?? profile.photoUrl,
    };

    const textSlip = buildWhatsAppSlip(
      cartItems,
      order.subtotal,
      order.discount,
      order.total,
      order.notes || '',
      orderProfile,
      order.id
    );

    const encoded = encodeURIComponent(textSlip);
    let targetUrl = `https://api.whatsapp.com/send?text=${encoded}`;

    if (order.dispatchMode === 'direct' && order.contactPhone) {
      let cleanPhone = order.contactPhone.replace(/[\s\-\(\)\+]/g, '');
      if (cleanPhone.startsWith('020')) cleanPhone = '85620' + cleanPhone.slice(3);
      targetUrl = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encoded}`;
    }

    window.open(targetUrl, '_blank');
    onShowToast(`🚀 ກຳລັງເປີດ WhatsApp ສຳລັບອໍເດີ້ ${order.id}...`, 'info');
  };

  // Copy Slip to Clipboard
  const handleCopyOrderSlip = async (order: Order) => {
    vibrateSoft();
    const cartItems = order.items.map((it) => ({
      product: {
        id: it.productId,
        name: it.productName,
        nameEn: it.productNameEn,
        sub: '',
        category: it.category,
        price: it.unitPrice,
        image: '',
      },
      quantity: it.quantity,
    }));

    const orderProfile: StoreProfile = {
      ...profile,
      name: order.storeName || profile.name,
      ownerName: order.ownerName || profile.ownerName,
      lat: order.location?.lat ?? profile.lat,
      lng: order.location?.lng ?? profile.lng,
      photoUrl: order.storePhoto ?? profile.photoUrl,
    };

    const textSlip = buildWhatsAppSlip(
      cartItems,
      order.subtotal,
      order.discount,
      order.total,
      order.notes || '',
      orderProfile,
      order.id
    );

    try {
      await navigator.clipboard.writeText(textSlip);
      onShowToast(`📋 ກັອບປີ້ໃບບິນ ${order.id} ແລ້ວ!`, 'success');
    } catch {
      onShowToast('ບໍ່ສາມາດກັອບປີ້ໄດ້', 'error');
    }
  };

  return (
    <div className="flex flex-col w-full pb-32 max-w-lg mx-auto px-4 pt-2">
      {/* Title & CSV Export */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="font-display font-bold text-[22px] text-[#006c49]">
            ປະຫວັດອໍເດີ້ທັງໝົດ
          </h1>
          <p className="text-[13px] text-[#3c4a42]">
            ບັນທຶກລາຍການຂາຍ {orders.length} ອໍເດີ້
          </p>
        </div>

        {orders.length > 0 && (
          <button
            onClick={() => {
              vibrateSoft();
              exportOrdersToCSV(orders);
              onShowToast('📥 ສົ່ງອອກໄຟລ໌ CSV ສຳເລັດແລ້ວ', 'success');
            }}
            className="flex items-center gap-1 bg-[#006c49] hover:bg-[#005236] text-white px-3 py-1.5 rounded-xl text-[12px] font-bold shadow-xs active:scale-95 transition-all"
            title="Export CSV"
          >
            <span className="material-symbols-outlined text-[16px]">file_download</span>
            <span>CSV</span>
          </button>
        )}
      </div>

      {orders.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 text-center border border-gray-100 shadow-sm flex flex-col items-center gap-3 my-4">
          <div className="w-16 h-16 rounded-full bg-[#ecfdf5] flex items-center justify-center text-[#006c49]">
            <span className="material-symbols-outlined text-[32px]">receipt_long</span>
          </div>
          <h3 className="font-display font-bold text-[18px] text-[#131b2e]">
            ຍັງບໍ່ມີປະຫວັດອໍເດີ້
          </h3>
          <p className="text-[13px] text-[#3c4a42] max-w-xs">
            ເມື່ອທ່ານເຮັດການຂາຍ ແລະ ສົ່ງໃບບິນ ອໍເດີ້ຈະຖືກບັນທຶກຢູ່ບ່ອນນີ້ອັດຕະໂນມັດ
          </p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {orders.map((order) => {
            const totalQty = order.items.reduce((sum, it) => sum + it.quantity, 0);

            return (
              <div
                key={order.id}
                className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 hover:border-[#10b981]/40 transition-all flex flex-col gap-2.5"
              >
                {/* Header row */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-display font-black text-[15px] text-[#006c49]">
                      {order.id}
                    </span>
                    <span className="text-[11px] bg-[#ecfdf5] text-[#006c49] font-bold px-2 py-0.5 rounded-md border border-[#a7f3d0]/50">
                      {order.dispatchMode === 'group' ? 'ກຸ່ມ WhatsApp' : 'ເບີໂທກົງ'}
                    </span>
                  </div>
                  <span className="text-[12px] text-gray-500 font-medium">
                    {formatDateTimeLao(order.createdAt)}
                  </span>
                </div>

                {/* Items summary */}
                <div className="text-[13px] text-[#131b2e] bg-[#faf8ff] p-2.5 rounded-xl border border-gray-100">
                  <div className="font-medium truncate">
                    {order.items.map((it) => `${it.productName} (x${it.quantity})`).join(', ')}
                  </div>
                  {order.notes && (
                    <div className="text-[11px] text-gray-500 mt-1 truncate">
                      📝 {order.notes}
                    </div>
                  )}
                </div>

                {/* Bottom row: Total amount & Actions */}
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-baseline gap-1">
                    <span className="text-[12px] text-gray-500">{totalQty} ລາຍການ •</span>
                    <span className="font-display font-black text-[18px] text-[#006c49]">
                      {formatKip(order.total)}
                    </span>
                    <span className="text-[11px] font-bold text-[#006c49]">ກີບ</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {/* Maps pin link */}
                    {order.location && (
                      <a
                        href={`https://www.google.com/maps?q=${order.location.lat},${order.location.lng}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-8 h-8 rounded-lg bg-[#ecfdf5] hover:bg-emerald-100 text-[#006c49] flex items-center justify-center transition-colors"
                        title="ເບິ່ງແຜນທີ່"
                      >
                        <span className="material-symbols-outlined text-[16px]">location_on</span>
                      </a>
                    )}

                    {/* Copy slip button */}
                    <button
                      onClick={() => handleCopyOrderSlip(order)}
                      className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 text-[#131b2e] flex items-center justify-center transition-colors"
                      title="ກັອບປີ້ໃບບິນ"
                    >
                      <span className="material-symbols-outlined text-[16px]">content_copy</span>
                    </button>

                    {/* Resend WhatsApp button */}
                    <button
                      onClick={() => handleResendWhatsApp(order)}
                      className="h-8 px-2.5 rounded-lg bg-[#25d366] hover:bg-[#20ba5a] text-white text-[12px] font-bold flex items-center gap-1 shadow-xs active:scale-95 transition-all"
                      title="ສົ່ງໃໝ່ຜ່ານ WhatsApp"
                    >
                      <span className="material-symbols-outlined text-[16px]">chat</span>
                      <span>ສົ່ງໃໝ່</span>
                    </button>

                    {/* Delete button */}
                    <button
                      onClick={() => {
                        vibrateSoft();
                        onDeleteOrder(order.id);
                        onShowToast(`ລຶບອໍເດີ້ ${order.id} ແລ້ວ`, 'info');
                      }}
                      className="w-8 h-8 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-600 flex items-center justify-center transition-colors"
                      title="ລຶບອໍເດີ້"
                    >
                      <span className="material-symbols-outlined text-[16px]">delete</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Clear history button */}
          <div className="pt-2 text-center">
            <button
              onClick={() => {
                if (window.confirm('ທ່ານຕ້ອງການລຶບປະຫວັດອໍເດີ້ທັງໝົດແທ້ຫຼືບໍ່?')) {
                  onClearAllOrders();
                  onShowToast('ລຶບປະຫວັດອໍເດີ້ທັງໝົດແລ້ວ', 'info');
                }
              }}
              className="text-[12px] text-gray-400 hover:text-red-600 transition-colors font-semibold"
            >
              ລຶບປະຫວັດອໍເດີ້ທັງໝົດ
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
