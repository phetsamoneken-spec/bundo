import React, { useState, useRef, useMemo } from 'react';
import confetti from 'canvas-confetti';
import { Product, StoreProfile, Order, CartItem } from '../../types/pos';
import { formatKip, vibrateSoft, compressImage, buildWhatsAppSlip } from '../../utils/formatters';
import { LeafletMap } from '../LeafletMap';

interface CartTabProps {
  products: Product[];
  cart: Record<string, number>;
  onUpdateQty: (productId: string, delta: number) => void;
  onSetQty: (productId: string, quantity: number) => void;
  onClearCart: () => void;
  profile: StoreProfile;
  onUpdateProfile: (updated: Partial<StoreProfile>) => void;
  onOrderCompleted: (order: Order) => void;
  onShowToast: (msg: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
  onGoToMenu: () => void;
}

export const CartTab: React.FC<CartTabProps> = ({
  products,
  cart,
  onUpdateQty,
  onSetQty,
  onClearCart,
  profile,
  onUpdateProfile,
  onOrderCompleted,
  onShowToast,
  onGoToMenu,
}) => {
  const [discount, setDiscount] = useState<number>(0);
  const [orderNotes, setOrderNotes] = useState<string>('');
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [directPhone, setDirectPhone] = useState<string>(profile.phone || '02055551234');
  const [isCompressingPhoto, setIsCompressingPhoto] = useState<boolean>(false);

  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  // Prepare cart items list
  const cartItems: CartItem[] = useMemo(() => {
    const list: CartItem[] = [];
    for (const [productId, qty] of Object.entries(cart)) {
      if (qty > 0) {
        const prod = products.find((p) => p.id === productId);
        if (prod) {
          list.push({ product: prod, quantity: qty });
        }
      }
    }
    return list;
  }, [cart, products]);

  // Totals
  const subtotal = useMemo(() => {
    return cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  }, [cartItems]);

  const netTotal = Math.max(0, subtotal - discount);

  // Trigger GPS
  const handleDetectGps = () => {
    vibrateSoft();
    if (!navigator.geolocation) {
      onShowToast('ບຣາວເຊີບໍ່ຮອງຮັບ GPS', 'warning');
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        const lat = Number(pos.coords.latitude.toFixed(5));
        const lng = Number(pos.coords.longitude.toFixed(5));
        onUpdateProfile({ lat, lng });
        onShowToast(`📍 ອັບເດດພິກັດ GPS ແລ້ວ: ${lat}, ${lng}`, 'success');
      },
      (err) => {
        setIsLocating(false);
        onShowToast('ບໍ່ສາມາດດຶງ GPS ໄດ້ ກະລຸນາອະນຸຍາດໃນບຣາວເຊີ', 'warning');
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  // Image upload handler
  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressingPhoto(true);
      const compressedDataUrl = await compressImage(file, 640, 0.7);
      onUpdateProfile({ photoUrl: compressedDataUrl });
      onShowToast('📸 ບັນທຶກຮູບພາບໜ້າຮ້ານແລ້ວ', 'success');
    } catch {
      onShowToast('ເກີດຂໍ້ຜິດພາດໃນການອັບໂຫຼດຮູບພາບ', 'error');
    } finally {
      setIsCompressingPhoto(false);
    }
  };

  // Create new order record
  const createOrderObject = (orderId?: string): Order => {
    return {
      id: orderId || `ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      createdAt: new Date().toISOString(),
      items: cartItems.map((item) => ({
        productId: item.product.id,
        productName: item.product.name,
        productNameEn: item.product.nameEn,
        category: item.product.category,
        quantity: item.quantity,
        unitPrice: item.product.price,
      })),
      subtotal,
      discount,
      total: netTotal,
      storeName: profile.name,
      ownerName: profile.ownerName || profile.cashierName,
      cashierName: profile.cashierName,
      contactPhone: directPhone,
      phone: directPhone,
      notes: orderNotes,
      location: { lat: profile.lat, lng: profile.lng },
      storePhoto: profile.photoUrl || undefined,
      dispatchMode: profile.whatsappMode,
    };
  };

  // WhatsApp Dispatch
  const handleSendWhatsApp = () => {
    vibrateSoft(50);
    if (cartItems.length === 0) {
      onShowToast('ກະຕ່າວ່າງເປົ່າ ກະລຸນາເລືອກເມນູກ່ອນ', 'warning');
      return;
    }

    const orderId = `ORD-${Math.floor(100000 + Math.random() * 900000)}`;
    const textSlip = buildWhatsAppSlip(
      cartItems,
      subtotal,
      discount,
      netTotal,
      orderNotes,
      profile,
      orderId
    );

    const encoded = encodeURIComponent(textSlip);
    let targetUrl = '';

    if (profile.whatsappMode === 'group') {
      // Group mode: no phone number triggers WhatsApp Chat/Group Picker
      targetUrl = `https://api.whatsapp.com/send?text=${encoded}`;
    } else {
      // Direct phone mode
      let cleanPhone = directPhone.replace(/[\s\-\(\)\+]/g, '');
      if (cleanPhone.startsWith('020')) {
        cleanPhone = '85620' + cleanPhone.slice(3);
      } else if (cleanPhone.startsWith('20')) {
        cleanPhone = '856' + cleanPhone;
      }
      targetUrl = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encoded}`;
    }

    // Save order record
    const newOrder = createOrderObject(orderId);
    onOrderCompleted(newOrder);

    // Confetti celebration
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.8 },
      });
    } catch {
      // ignore
    }

    // Open WhatsApp
    window.open(targetUrl, '_blank');
    onShowToast('🚀 ກຳລັງເປີດ WhatsApp ເພື່ອສົ່ງໃບບິນ...', 'success');
  };

  // Copy Slip to Clipboard
  const handleCopySlip = async () => {
    vibrateSoft(30);
    if (cartItems.length === 0) {
      onShowToast('ກະຕ່າວ່າງເປົ່າ ບໍ່ມີລາຍການໃຫ້ກັອບປີ້', 'warning');
      return;
    }

    const textSlip = buildWhatsAppSlip(
      cartItems,
      subtotal,
      discount,
      netTotal,
      orderNotes,
      profile
    );

    try {
      await navigator.clipboard.writeText(textSlip);
      onShowToast('📋 ກັອບປີ້ຂໍ້ຄວາມໃບບິນໃສ່ຄລິບບອດແລ້ວ!', 'success');
    } catch {
      onShowToast('ບໍ່ສາມາດກັອບປີ້ໄດ້ ກະລຸນາລອງໃໝ່', 'error');
    }
  };

  // Quick Finish Sale without WhatsApp
  const handleFinishSale = () => {
    vibrateSoft(40);
    if (cartItems.length === 0) {
      onShowToast('ກະຕ່າວ່າງເປົ່າ ກະລຸນາເລືອກເມນູກ່ອນ', 'warning');
      return;
    }

    const newOrder = createOrderObject();
    onOrderCompleted(newOrder);

    try {
      confetti({
        particleCount: 70,
        spread: 70,
        origin: { y: 0.7 },
      });
    } catch {
      // ignore
    }

    onShowToast(`✅ ບັນທຶກອໍເດີ້ ${newOrder.id} ສຳເລັດແລ້ວ!`, 'success');
    onClearCart();
    setDiscount(0);
    setOrderNotes('');
  };

  return (
    <div className="flex flex-col w-full pb-32 max-w-lg mx-auto px-4 pt-2">
      {/* Hidden file inputs */}
      <input
        type="file"
        ref={cameraInputRef}
        accept="image/*"
        capture="environment"
        onChange={handlePhotoUpload}
        className="hidden"
      />
      <input
        type="file"
        ref={galleryInputRef}
        accept="image/*"
        onChange={handlePhotoUpload}
        className="hidden"
      />

      {/* Title */}
      <div className="flex items-center justify-between mb-3">
        <div>
          <h1 className="font-display font-bold text-[22px] text-[#006c49]">
            ກະຕ່າສິນຄ້າ &amp; ສົ່ງ WhatsApp
          </h1>
          <p className="text-[13px] text-[#3c4a42]">ກວດສອບລາຍການ, ພິກັດ ແລະ ສົ່ງໃບບິນ</p>
        </div>
        {cartItems.length > 0 && (
          <button
            onClick={() => {
              vibrateSoft();
              onClearCart();
              onShowToast('ລ້າງກະຕ່າຮຽບຮ້ອຍແລ້ວ', 'info');
            }}
            className="text-[12px] font-bold text-[#ba1a1a] hover:bg-red-50 px-2.5 py-1 rounded-lg transition-colors border border-red-200"
          >
            ລ້າງກະຕ່າ
          </button>
        )}
      </div>

      {/* Cart Items List */}
      {cartItems.length === 0 ? (
        <div className="bg-white rounded-3xl p-6 text-center border border-gray-100 shadow-sm flex flex-col items-center gap-3 my-2">
          <div className="w-16 h-16 rounded-full bg-[#ecfdf5] flex items-center justify-center text-[#006c49]">
            <span className="material-symbols-outlined text-[32px]">shopping_cart</span>
          </div>
          <h3 className="font-display font-bold text-[18px] text-[#131b2e]">
            ຍັງບໍ່ມີສິນຄ້າໃນກະຕ່າ
          </h3>
          <p className="text-[13px] text-[#3c4a42] max-w-xs">
            ກົດປຸ່ມດ້ານລຸ່ມເພື່ອເລືອກສິນຄ້າຈາກເມນູໜ້າຮ້ານ
          </p>
          <button
            onClick={() => {
              vibrateSoft();
              onGoToMenu();
            }}
            className="mt-2 px-5 py-2.5 bg-[#006c49] text-white font-bold rounded-xl text-[14px] shadow-sm active:scale-95 transition-all flex items-center gap-1.5"
          >
            <span className="material-symbols-outlined text-[18px]">add_shopping_cart</span>
            <span>ໄປເລືອກເມນູສິນຄ້າ</span>
          </button>
        </div>
      ) : (
        <div className="flex flex-col gap-2.5 mb-4">
          <div className="text-[13px] font-bold text-[#3c4a42] flex items-center justify-between">
            <span>ລາຍການສິນຄ້າ ({cartItems.length})</span>
            <span className="text-[#006c49] font-medium">ລວມ {cartItems.reduce((acc, c) => acc + c.quantity, 0)} ຈຳນວນ</span>
          </div>

          <div className="flex flex-col gap-2">
            {cartItems.map((item) => (
              <div
                key={item.product.id}
                className="bg-white rounded-2xl p-3 shadow-xs border border-gray-100 flex items-center gap-3"
              >
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-14 h-14 rounded-xl object-cover bg-[#ecfdf5] shrink-0"
                />

                <div className="flex-1 min-w-0">
                  <h4 className="font-display font-bold text-[15px] text-[#131b2e] truncate">
                    {item.product.name}
                  </h4>
                  <p className="text-[12px] text-[#006c49] font-bold">
                    {formatKip(item.product.price)} ກີບ
                  </p>
                </div>

                {/* Stepper */}
                <div className="flex items-center gap-1 bg-[#ecfdf5] rounded-xl p-1 border border-[#a7f3d0]/50 shrink-0">
                  <button
                    onClick={() => {
                      vibrateSoft();
                      onUpdateQty(item.product.id, -1);
                    }}
                    className="w-7 h-7 rounded-lg bg-white text-[#006c49] flex items-center justify-center font-bold shadow-xs active:scale-90 transition-transform"
                  >
                    <span className="material-symbols-outlined text-[16px]">remove</span>
                  </button>

                  <input
                    type="number"
                    min="1"
                    max="999"
                    value={item.quantity}
                    onChange={(e) => {
                      const val = parseInt(e.target.value, 10);
                      onSetQty(item.product.id, isNaN(val) ? 0 : val);
                    }}
                    onFocus={(e) => e.target.select()}
                    className="w-8 text-center bg-transparent font-display font-black text-[15px] text-[#006c49] focus:outline-none"
                  />

                  <button
                    onClick={() => {
                      vibrateSoft();
                      onUpdateQty(item.product.id, 1);
                    }}
                    className="w-7 h-7 rounded-lg bg-[#006c49] text-white flex items-center justify-center font-bold shadow-xs active:scale-90 transition-transform"
                  >
                    <span className="material-symbols-outlined text-[16px]">add</span>
                  </button>
                </div>

                {/* Total for this line */}
                <div className="text-right min-w-[70px]">
                  <span className="font-display font-bold text-[14px] text-[#131b2e]">
                    {formatKip(item.product.price * item.quantity)}
                  </span>
                  <div className="text-[10px] text-gray-400">ກີບ</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Special Notes & Discount Card */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col gap-3 mb-4">
        <h3 className="font-display font-bold text-[15px] text-[#131b2e] flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[18px] text-[#006c49]">tune</span>
          <span>ໝາຍເຫດ &amp; ສ່ວນຫຼຸດ</span>
        </h3>

        {/* Order Notes */}
        <div>
          <label className="text-[12px] font-semibold text-[#3c4a42] block mb-1">
            ໝາຍເຫດພິເສດ (ລົດຊາດ, ຄວາມຫວານ, ອື່ນໆ)
          </label>
          <input
            type="text"
            value={orderNotes}
            onChange={(e) => setOrderNotes(e.target.value)}
            placeholder="ເຊັ່ນ: ຫວານ 50%, ບໍ່ໃສ່ຜັກຊີ, ຕື່ມນ້ຳກ້ອນແຍກ..."
            className="w-full px-3.5 py-2.5 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
          />
        </div>

        {/* Discount Input */}
        <div>
          <label className="text-[12px] font-semibold text-[#3c4a42] block mb-1">
            ສ່ວນຫຼຸດພິເສດ (ກີບ)
          </label>
          <div className="relative">
            <input
              type="number"
              min="0"
              step="1000"
              value={discount === 0 ? '' : discount}
              onChange={(e) => setDiscount(Math.max(0, parseInt(e.target.value || '0', 10)))}
              placeholder="0 ກີບ"
              className="w-full px-3.5 py-2.5 bg-[#faf8ff] rounded-xl border border-gray-200 text-[14px] font-display font-bold text-[#ba1a1a] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
            />
            <span className="absolute right-3.5 top-2.5 text-[12px] text-gray-500 font-bold">
              ກີບ
            </span>
          </div>
        </div>

        {/* Financial calculation breakdown */}
        <div className="pt-2 border-t border-gray-100 flex flex-col gap-1.5 text-[13px]">
          <div className="flex justify-between text-[#3c4a42]">
            <span>ຍອດລວມສິນຄ້າ:</span>
            <span className="font-display font-bold text-[#131b2e]">{formatKip(subtotal)} ກີບ</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-[#ba1a1a]">
              <span>ສ່ວນຫຼຸດ:</span>
              <span className="font-display font-bold">-{formatKip(discount)} ກີບ</span>
            </div>
          )}
          <div className="flex justify-between items-baseline pt-1.5 border-t border-dashed border-gray-200">
            <span className="font-display font-bold text-[16px] text-[#131b2e]">
              ຍອດຊຳລະສຸດທິ:
            </span>
            <div className="text-right">
              <span className="font-display font-black text-[24px] text-[#006c49]">
                {formatKip(netTotal)}
              </span>
              <span className="text-[13px] font-bold text-[#006c49] ml-1">ກີບ</span>
            </div>
          </div>
        </div>
      </div>

      {/* Store & Owner Details Card */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col gap-3 mb-4">
        <h3 className="font-display font-bold text-[15px] text-[#131b2e] flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[18px] text-[#006c49]">storefront</span>
          <span>ຂໍ້ມູນຮ້ານ &amp; ເຈົ້າຂອງຮ້ານ</span>
        </h3>

        {/* Store Name & Owner Name */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div>
            <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
              ຊື່ຮ້ານ (Store Name) *
            </label>
            <input
              type="text"
              value={profile.name}
              onChange={(e) => onUpdateProfile({ name: e.target.value })}
              placeholder="ຊື່ຮ້ານຂອງທ່ານ"
              className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] font-semibold text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
            />
          </div>

          <div>
            <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
              ເຈົ້າຂອງຮ້ານ / ຜູ້ຕິດຕໍ່ (Owner) *
            </label>
            <input
              type="text"
              value={profile.ownerName || profile.cashierName || ''}
              onChange={(e) => {
                onUpdateProfile({ ownerName: e.target.value, cashierName: e.target.value });
              }}
              placeholder="ຊື່ເຈົ້າຂອງຮ້ານ"
              className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] font-semibold text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
            />
          </div>
        </div>

        {/* Phone */}
        <div>
          <label className="text-[12px] font-bold text-[#3c4a42] block mb-1">
            ເບີໂທຕິດຕໍ່ຮ້ານ (Phone)
          </label>
          <input
            type="tel"
            value={profile.phone}
            onChange={(e) => onUpdateProfile({ phone: e.target.value })}
            placeholder="020 xxxx xxxx"
            className="w-full px-3 py-2 bg-[#faf8ff] rounded-xl border border-gray-200 text-[13px] font-display font-semibold text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#10b981]"
          />
        </div>
      </div>

      {/* Target Dispatch Mode (WhatsApp Group vs Direct Phone) */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col gap-3 mb-4">
        <h3 className="font-display font-bold text-[15px] text-[#131b2e] flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[18px] text-[#25d366]">send</span>
          <span>ຮູບແບບການສົ່ງ WhatsApp</span>
        </h3>

        {/* Toggle Pills */}
        <div className="grid grid-cols-2 gap-2 bg-[#ecfdf5] p-1 rounded-xl">
          <button
            type="button"
            onClick={() => {
              vibrateSoft();
              onUpdateProfile({ whatsappMode: 'group' });
            }}
            className={`py-2 px-3 rounded-lg text-[13px] font-bold transition-all flex items-center justify-center gap-1.5 ${
              profile.whatsappMode === 'group'
                ? 'bg-[#006c49] text-white shadow-sm'
                : 'text-[#006c49] hover:bg-white/50'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">groups</span>
            <span>ສົ່ງເຂົ້າກຸ່ມ (Group)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              vibrateSoft();
              onUpdateProfile({ whatsappMode: 'direct' });
            }}
            className={`py-2 px-3 rounded-lg text-[13px] font-bold transition-all flex items-center justify-center gap-1.5 ${
              profile.whatsappMode === 'direct'
                ? 'bg-[#006c49] text-white shadow-sm'
                : 'text-[#006c49] hover:bg-white/50'
            }`}
          >
            <span className="material-symbols-outlined text-[16px]">phone_iphone</span>
            <span>ສົ່ງຫາເບີໂທ (Direct)</span>
          </button>
        </div>

        {profile.whatsappMode === 'direct' ? (
          <div>
            <label className="text-[12px] font-semibold text-[#3c4a42] block mb-1">
              ເບີໂທ WhatsApp ປາຍທາງ (ເຊັ່ນ: 020 5555 1234)
            </label>
            <input
              type="tel"
              value={directPhone}
              onChange={(e) => {
                setDirectPhone(e.target.value);
                onUpdateProfile({ phone: e.target.value });
              }}
              placeholder="020 xxxx xxxx"
              className="w-full px-3.5 py-2.5 bg-[#faf8ff] rounded-xl border border-gray-200 text-[14px] font-display font-semibold text-[#131b2e] focus:outline-none focus:ring-2 focus:ring-[#25d366]"
            />
          </div>
        ) : (
          <p className="text-[12px] text-[#3c4a42] bg-[#ecfdf5] p-2.5 rounded-xl border border-[#a7f3d0]/60">
            💡 <strong>ໂໝດກຸ່ມ:</strong> ເມື່ອກົດສົ່ງ ລະບົບຈະເປີດ WhatsApp ໃຫ້ທ່ານເລືອກຫ້ອງແຊັດ ຫຼື ກຸ່ມລູກຄ້າທີ່ຕ້ອງການໄດ້ທັນທີ.
          </p>
        )}
      </div>

      {/* Store Location Map & Coordinates */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col gap-3 mb-4">
        <div className="flex items-center justify-between">
          <h3 className="font-display font-bold text-[15px] text-[#131b2e] flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[18px] text-[#006c49]">location_on</span>
            <span>ພິກັດແຜນທີ່ຮ້ານ (Google Maps)</span>
          </h3>
          <button
            onClick={handleDetectGps}
            disabled={isLocating}
            className="text-[11px] font-bold text-[#006c49] bg-[#ecfdf5] hover:bg-emerald-100 px-2.5 py-1 rounded-lg flex items-center gap-1 active:scale-95 transition-all border border-[#a7f3d0]/50"
          >
            {isLocating ? (
              <span className="w-3 h-3 border-2 border-[#006c49] border-t-transparent rounded-full animate-spin"></span>
            ) : (
              <span className="material-symbols-outlined text-[14px]">my_location</span>
            )}
            <span>GPS ສົດ</span>
          </button>
        </div>

        {/* Leaflet Map with CARTO Voyager */}
        <LeafletMap
          lat={profile.lat}
          lng={profile.lng}
          onPositionChange={(lat, lng) => onUpdateProfile({ lat, lng })}
          height="190px"
        />

        <div className="flex items-center justify-between text-[11px] text-[#3c4a42] px-1">
          <span>ພິກັດ: {profile.lat.toFixed(5)}, {profile.lng.toFixed(5)}</span>
          <a
            href={`https://www.google.com/maps?q=${profile.lat},${profile.lng}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#006c49] font-bold hover:underline flex items-center gap-0.5"
          >
            <span>ເປີດ Google Maps</span>
            <span className="material-symbols-outlined text-[12px]">open_in_new</span>
          </a>
        </div>
      </div>

      {/* Storefront Photo Capture */}
      <div className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex flex-col gap-3 mb-6">
        <h3 className="font-display font-bold text-[15px] text-[#131b2e] flex items-center gap-1.5">
          <span className="material-symbols-outlined text-[18px] text-[#006c49]">add_a_photo</span>
          <span>ຮູບພາບໜ້າຮ້ານ / ຈຸດຮັບເຄື່ອງ</span>
        </h3>

        {profile.photoUrl ? (
          <div className="relative rounded-xl overflow-hidden border border-emerald-900/10 shadow-sm aspect-video bg-gray-50">
            <img
              src={profile.photoUrl}
              alt="Storefront"
              className="w-full h-full object-cover"
            />
            <button
              onClick={() => {
                vibrateSoft();
                onUpdateProfile({ photoUrl: null });
                onShowToast('ລຶບຮູບພາບໜ້າຮ້ານແລ້ວ', 'info');
              }}
              className="absolute top-2 right-2 bg-black/70 hover:bg-red-600 text-white p-1.5 rounded-full backdrop-blur-md transition-colors shadow-md"
              title="ລຶບຮູບພາບ"
            >
              <span className="material-symbols-outlined text-[16px]">delete</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                vibrateSoft();
                cameraInputRef.current?.click();
              }}
              disabled={isCompressingPhoto}
              className="py-3 px-3 bg-[#faf8ff] hover:bg-[#ecfdf5] border border-dashed border-[#006c49]/30 rounded-xl text-center flex flex-col items-center justify-center gap-1 active:scale-95 transition-all text-[#006c49]"
            >
              <span className="material-symbols-outlined text-[24px]">photo_camera</span>
              <span className="text-[12px] font-bold">ຖ່າຍຮູບໜ້າຮ້ານ</span>
            </button>

            <button
              onClick={() => {
                vibrateSoft();
                galleryInputRef.current?.click();
              }}
              disabled={isCompressingPhoto}
              className="py-3 px-3 bg-[#faf8ff] hover:bg-[#ecfdf5] border border-dashed border-[#006c49]/30 rounded-xl text-center flex flex-col items-center justify-center gap-1 active:scale-95 transition-all text-[#006c49]"
            >
              <span className="material-symbols-outlined text-[24px]">image</span>
              <span className="text-[12px] font-bold">ເລືອກຈາກຄັງ</span>
            </button>
          </div>
        )}
      </div>

      {/* Live WhatsApp Slip Preview */}
      {cartItems.length > 0 && (
        <div className="bg-[#ecfdf5] rounded-2xl p-4 shadow-sm border border-[#a7f3d0] flex flex-col gap-2.5 mb-5">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-[14px] text-[#006c49] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[18px]">preview</span>
              <span>ຕົວຢ່າງຂໍ້ຄວາມທີ່ຈະສົ່ງເຂົ້າ WhatsApp</span>
            </h3>
            <span className="text-[11px] font-bold text-[#006c49] bg-white px-2 py-0.5 rounded-full border border-[#a7f3d0]">
              Real-time Preview
            </span>
          </div>

          <div className="bg-white/95 rounded-xl p-3 border border-emerald-900/10 text-[12px] font-mono text-[#131b2e] leading-relaxed whitespace-pre-wrap max-h-48 overflow-y-auto shadow-inner select-text">
            {buildWhatsAppSlip(cartItems, subtotal, discount, netTotal, orderNotes, profile)}
          </div>
        </div>
      )}

      {/* Main Action Buttons */}
      <div className="flex flex-col gap-2.5">
        {/* WhatsApp Dispatch Button */}
        <button
          onClick={handleSendWhatsApp}
          disabled={cartItems.length === 0}
          className="w-full py-3.5 px-4 bg-[#25d366] hover:bg-[#20ba5a] text-white font-display font-bold text-[16px] rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/15 active:scale-98 transition-all disabled:opacity-50"
        >
          <span className="material-symbols-outlined text-[24px]">chat</span>
          <span>ສະຫຼຸບ &amp; ສົ່ງເຂົ້າ WhatsApp</span>
          <span className="material-symbols-outlined text-[20px]">arrow_forward</span>
        </button>

        {/* Dual button row: Copy Slip & Complete Sale */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handleCopySlip}
            disabled={cartItems.length === 0}
            className="py-3 px-3 bg-white hover:bg-gray-50 border border-gray-200 text-[#131b2e] font-bold text-[13px] rounded-xl flex items-center justify-center gap-1.5 shadow-xs active:scale-95 transition-all disabled:opacity-50"
          >
            <span className="material-symbols-outlined text-[18px] text-[#006c49]">content_copy</span>
            <span>ກັອບປີ້ໃບບິນ (1-Click)</span>
          </button>

          <button
            onClick={handleFinishSale}
            disabled={cartItems.length === 0}
            className="py-3 px-3 bg-[#006c49] hover:bg-[#005236] text-white font-bold text-[13px] rounded-xl flex items-center justify-center gap-1.5 shadow-xs active:scale-95 transition-all disabled:opacity-50"
          >
            <span className="material-symbols-outlined text-[18px]">check_circle</span>
            <span>ສຳເລັດການຂາຍ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
