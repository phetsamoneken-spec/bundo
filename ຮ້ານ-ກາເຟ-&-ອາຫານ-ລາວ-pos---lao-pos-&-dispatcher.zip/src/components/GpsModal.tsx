import React, { useState } from 'react';
import { vibrateSoft } from '../utils/formatters';

interface GpsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLat: number;
  currentLng: number;
  onUpdateLocation: (lat: number, lng: number) => void;
  onShowToast: (msg: string, type?: 'success' | 'info' | 'warning' | 'error') => void;
}

export const GpsModal: React.FC<GpsModalProps> = ({
  isOpen,
  onClose,
  currentLat,
  currentLng,
  onUpdateLocation,
  onShowToast,
}) => {
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleRequestGps = () => {
    vibrateSoft();
    if (!navigator.geolocation) {
      onShowToast('ບຣາວເຊີຂອງທ່ານບໍ່ຮອງຮັບລະບົບ GPS Geolocation', 'warning');
      return;
    }

    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLoading(false);
        const lat = Number(pos.coords.latitude.toFixed(5));
        const lng = Number(pos.coords.longitude.toFixed(5));
        onUpdateLocation(lat, lng);
        onShowToast(`📍 ອັບເດດພິກັດ GPS ສຳເລັດ: ${lat}, ${lng}`, 'success');
        onClose();
      },
      (err) => {
        setLoading(false);
        let msg = 'ບໍ່ສາມາດດຶງຕຳແໜ່ງ GPS ໄດ້';
        if (err.code === 1) {
          msg = 'ກະລຸນາອະນຸຍາດການເຂົ້າເຖິງຕຳແໜ່ງ GPS ໃນບຣາວເຊີຂອງທ່ານ';
        }
        onShowToast(msg, 'warning');
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl border border-emerald-900/10 flex flex-col gap-4">
        {/* Header icon */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#ecfdf5] flex items-center justify-center text-[#006c49]">
            <span className="material-symbols-outlined text-[28px]">explore</span>
          </div>
          <div className="flex-1">
            <h3 className="font-display font-bold text-lg text-[#006c49] leading-tight">
              ການຕັ້ງຄ່າ GPS ໜ້າຮ້ານ
            </h3>
            <p className="text-xs text-[#3c4a42]">
              ສຳລັບແນບລິ້ງຄ໌ Google Maps ໃນໃບບິນ
            </p>
          </div>
        </div>

        {/* Current status display */}
        <div className="bg-[#faf8ff] p-3.5 rounded-2xl border border-[#dae2fd]/60 flex flex-col gap-1.5 text-xs text-[#3c4a42]">
          <div className="flex justify-between items-center">
            <span className="font-medium text-[#131b2e]">ພິກັດປັດຈຸບັນ:</span>
            <span className="font-display font-bold text-[#006c49] bg-[#ecfdf5] px-2 py-0.5 rounded-md">
              {currentLat.toFixed(4)}, {currentLng.toFixed(4)}
            </span>
          </div>
          <p className="text-[11px] text-gray-500 mt-1 leading-relaxed">
            ລະບົບຈະສ້າງລິ້ງຄ໌ Google Maps ອັດຕະໂນມັດ ເພື່ອໃຫ້ລູກຄ້າ ຫຼື ທີມສົ່ງເຄື່ອງສາມາດກົດນຳທາງມາຮອດຮ້ານໄດ້ທັນທີຜ່ານ WhatsApp.
          </p>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col gap-2 pt-1">
          <button
            onClick={handleRequestGps}
            disabled={loading}
            className="w-full py-3 px-4 bg-[#006c49] hover:bg-[#005236] text-white rounded-xl font-bold flex items-center justify-center gap-2 shadow-md active:scale-95 transition-all disabled:opacity-50"
          >
            {loading ? (
              <>
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                <span>ກຳລັງຄົ້ນຫາ GPS...</span>
              </>
            ) : (
              <>
                <span className="material-symbols-outlined text-[20px]">my_location</span>
                <span>ອະນຸຍາດນຳໃຊ້ GPS (ດຶງພິກັດສົດ)</span>
              </>
            )}
          </button>

          <button
            onClick={onClose}
            className="w-full py-2.5 px-4 bg-[#ecfdf5] hover:bg-emerald-100 text-[#006c49] rounded-xl font-semibold flex items-center justify-center gap-2 active:scale-95 transition-all text-xs"
          >
            <span className="material-symbols-outlined text-[18px]">touch_app</span>
            <span>ປັບໝຸດເອງເທິງແຜນທີ່ໃນໜ້າກະຕ່າ</span>
          </button>
        </div>
      </div>
    </div>
  );
};
