import React from 'react';
import { ActiveTab } from '../types/pos';
import { vibrateSoft } from '../utils/formatters';

interface BottomNavProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  cartTotalCount: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  cartTotalCount,
}) => {
  const tabs: {
    id: ActiveTab;
    label: string;
    icon: string;
    badge?: number;
  }[] = [
    {
      id: 'pos-menu',
      label: 'ເມນູສິນຄ້າ',
      icon: 'shopping_bag',
    },
    {
      id: 'cart-and-whatsapp',
      label: 'ກະຕ່າ & WhatsApp',
      icon: 'shopping_cart',
      badge: cartTotalCount,
    },
    {
      id: 'sales-dashboard',
      label: 'ສະຫຼຸບຍອດ',
      icon: 'bar_chart',
    },
    {
      id: 'order-history',
      label: 'ປະຫວັດອໍເດີ້',
      icon: 'receipt_long',
    },
    {
      id: 'catalog-settings',
      label: 'ຈັດການ',
      icon: 'tune',
    },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 pointer-events-none px-3 pb-3">
      <div className="pointer-events-auto mx-auto max-w-lg bg-white/90 backdrop-blur-xl rounded-2xl shadow-[0_12px_32px_-4px_rgba(15,23,42,0.15),0_4px_12px_-2px_rgba(16,185,129,0.1)] border border-white/80 flex items-center justify-between p-1.5">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                vibrateSoft(15);
                onChangeTab(tab.id);
              }}
              className={`flex flex-col items-center justify-center flex-1 py-1 px-0.5 rounded-xl transition-all duration-200 min-h-[52px] ${
                isActive
                  ? 'text-[#006c49] font-bold bg-[#ecfdf5] scale-105 shadow-xs'
                  : 'text-[#3c4a42] hover:text-[#006c49] font-medium active:scale-95'
              }`}
            >
              <div className="relative flex items-center justify-center">
                <span
                  className={`material-symbols-outlined text-[22px] transition-transform ${
                    isActive ? 'scale-110 text-[#006c49]' : ''
                  }`}
                >
                  {tab.icon}
                </span>

                {typeof tab.badge === 'number' && tab.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[18px] h-[18px] bg-[#10b981] text-white font-display text-[10px] font-extrabold rounded-full flex items-center justify-center px-1 shadow-sm animate-pulse">
                    {tab.badge > 99 ? '99+' : tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] mt-0.5 text-center leading-tight truncate w-full">
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
