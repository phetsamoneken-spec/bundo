import React, { useEffect, useRef } from 'react';
import L from 'leaflet';

interface LeafletMapProps {
  lat: number;
  lng: number;
  onPositionChange: (lat: number, lng: number) => void;
  height?: string;
}

export const LeafletMap: React.FC<LeafletMapProps> = ({
  lat,
  lng,
  onPositionChange,
  height = '200px',
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Initialize Leaflet map
      const map = L.map(mapContainerRef.current, {
        center: [lat, lng],
        zoom: 15,
        zoomControl: true,
        attributionControl: false,
      });

      // Use CARTO Voyager raster tiles as explicitly instructed
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      // Create custom SVG Pin Icon for crispness and zero broken asset paths
      const customIcon = L.divIcon({
        className: 'custom-leaflet-pin',
        html: `
          <div style="position: relative; width: 36px; height: 44px; display: flex; align-items: center; justify-content: center; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.3));">
            <svg width="36" height="44" viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M18 0C8.05887 0 0 8.05887 0 18C0 28.5 15.5 42.5 17.1 43.8C17.6 44.2 18.4 44.2 18.9 43.8C20.5 42.5 36 28.5 36 18C36 8.05887 27.9411 0 18 0Z" fill="#006c49"/>
              <circle cx="18" cy="17" r="7" fill="white"/>
              <circle cx="18" cy="17" r="4" fill="#10b981"/>
            </svg>
          </div>
        `,
        iconSize: [36, 44],
        iconAnchor: [18, 44],
        popupAnchor: [0, -40],
      });

      const marker = L.marker([lat, lng], {
        draggable: true,
        icon: customIcon,
      }).addTo(map);

      marker.on('dragend', () => {
        const position = marker.getLatLng();
        onPositionChange(Number(position.lat.toFixed(5)), Number(position.lng.toFixed(5)));
      });

      map.on('click', (e) => {
        marker.setLatLng(e.latlng);
        onPositionChange(Number(e.latlng.lat.toFixed(5)), Number(e.latlng.lng.toFixed(5)));
      });

      mapInstanceRef.current = map;
      markerRef.current = marker;

      // Invalidate size to ensure clean render inside flex/tabs
      setTimeout(() => {
        map.invalidateSize();
      }, 200);
    } else {
      // Update existing map view & marker position
      mapInstanceRef.current.setView([lat, lng], mapInstanceRef.current.getZoom());
      if (markerRef.current) {
        markerRef.current.setLatLng([lat, lng]);
      }
    }

    return () => {
      // cleanup on unmount
    };
  }, [lat, lng, onPositionChange]);

  // Handle map resize on re-render
  useEffect(() => {
    const timer = setTimeout(() => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.invalidateSize();
      }
    }, 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative w-full rounded-2xl overflow-hidden border border-emerald-900/15 shadow-sm">
      <div ref={mapContainerRef} style={{ height }} className="w-full bg-[#e2e7ff]" />
      
      {/* Real-time coordinates floating badge */}
      <div className="absolute top-2 left-2 z-[400] bg-black/75 backdrop-blur-md text-white text-[11px] font-display font-medium px-2.5 py-1 rounded-full shadow-md flex items-center gap-1.5 border border-white/20">
        <span className="w-2 h-2 rounded-full bg-[#10b981] animate-ping"></span>
        <span>{lat.toFixed(4)}, {lng.toFixed(4)}</span>
      </div>

      <div className="absolute bottom-2 right-2 z-[400] bg-white/90 backdrop-blur-md text-[#006c49] text-[10px] font-bold px-2 py-0.5 rounded-md shadow-xs border border-emerald-800/10">
        ລາກໝຸດເພື່ອປັບຕຳແໜ່ງ
      </div>
    </div>
  );
};
